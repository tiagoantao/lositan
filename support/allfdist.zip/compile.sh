gcc Ddatacal.c as100.c as99.c -o Ddatacal.mac
gcc Dfdist.c as100.c as99.c -o Dfdist.mac
gcc cplot.c as100.c as99.c -o cplot.mac
gcc cplot2.c as100.c as99.c -o cplot2.mac
gcc datacal.c as100.c as99.c -o datacal.mac
gcc fdist2.c as100.c as99.c -o fdist2.mac
gcc pv.c as100.c as99.c -lm -o pv.mac
gcc pv2.c as100.c as99.c -lm -o pv2.mac
